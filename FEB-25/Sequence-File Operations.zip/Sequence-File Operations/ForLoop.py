a = [4, 7, 3, 2, 5, 9]

for index, value in enumerate(a):
    print(f"Position {index}: {value}")
