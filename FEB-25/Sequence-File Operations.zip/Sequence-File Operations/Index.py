input_string=input()
output_string=input_string[::2]
print(output_string)