input_string=input()
output_string=input_string[::-1]
print(output_string)